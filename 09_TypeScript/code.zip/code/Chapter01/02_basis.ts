let a: number;
a = 5;
a = "hello"; // 报错

let b: string;
b = "Hello";
b = 5; // 报错

let c = false; // 自动判断类型
c = true;
c = "yes"; // 报错

// 约定函数参数和返回值的类型
function sum(a: number, b: number): number {
  return a + b;
}
