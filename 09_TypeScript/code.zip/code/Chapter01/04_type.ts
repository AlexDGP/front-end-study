// object
let a: object;
a = {};
a = function () {};

let b: { name: string; age?: string }; // ?后面是可选属性
b = { name: "Alex" };
b = { age: 18 }; // 报错

let c: { name: string; [propName: string]: any }; // 必须要有name属性
c = { name: "Alex" };
c = { name: "Alex", gender: "male" };

// 函数
let d: (a: number, b: number) => number;
let e = function (a: number, b: number): number {
  return 0;
};

// 数组
let f: string[];
let g: Array<string>;

// 元组
let h: [string, number];
h = [10, 20]; // 报错
h = ["10", 20];

// 枚举
enum Gender {
  Male,
  Female,
}
let person: { name: string; gender: Gender };
person = {
  name: "Alex",
  gender: Gender.Male,
};

// &符
let and: { name: string } & { age: number };
and = { name: "Alex", age: 18 };
and = { name: "Alex" }; // 报错

// 类型别名
type myType = 1 | 2 | 3;
let type1: myType;
type1 = 6; // 报错
type1 = 2;
