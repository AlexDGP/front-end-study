// 字面量声明
let a: 10;
a = 10;
a = 11; // 报错

// 联合类型
let b: "male" | "female";
b = "male";
b = "female";
b = "good"; // 报错

let c: boolean | string;
c = false;
c = "hello";
c = 0; // 报错

// 任意类型,几乎不建议用
let d: any;
d = "yes";
d = true;
d = { name: "value" };
d = null;

let str: string;
// 不指定类型,自动判断任意类型
let e;
e = "yes";
e = true;
e = { name: "value" };
e = null;
str = e; // 不报错,破坏其他变量的强类型判断

// 未知类型
let f: unknown;
f = "yes";
f = true;
f = { name: "value" };
f = null;
str = f; // 报错,不会破坏其他变量的强类型判断
if (typeof f === "string") {
  str = f; // 不报错,判断了类型
}
str = f as string; // 类型断言
str = <string>f; // 类型断言

function fn1(): void {
  // return "a"; // 报错
  // return undefined; // 不报错
  return null; // 不报错
}

function fn2(): never {
  // return "a"; // 报错
  // return undefined; // 报错
  // return null; // 报错
  throw new Error("error"); // 不报错
}
