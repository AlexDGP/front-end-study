let a: number = 16;
a = 18;
a = 55;
