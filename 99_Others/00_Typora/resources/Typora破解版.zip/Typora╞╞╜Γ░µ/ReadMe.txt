运行Setup.exe安装Typora
将winmm.dll解压到Typora根目录下(报毒,记得信任该文件)