// 引入express
const express = require("express");

// 创建express对象
const app = express();

// 创建路由规则
// request是请求报文的封装
// response是响应报文的封装
// post
app.post("/server", (request, response) => {
  // 设置响应头
  response.setHeader("Access-Control-Allow-Origin", "*"); // 允许跨域
  response.send("Hello AJAX POST"); // 设置响应体
});

// 监听8000端口启动服务
const port = 8000;
app.listen(port, () => {
  console.log(`服务已启动,${port}端口正在监听中...`);
});
