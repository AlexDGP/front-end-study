const express = require("express");
const app = express();

app.all("/check-username", (req, res) => {
  const data = {
    exist: 1,
    msg: "用户名已存在",
  };
  let str = JSON.stringify(data);
  res.end(`handle(${str})`);
});

const port = 8000;
app.listen(port, () => {
  console.log(`服务已启动,${port}端口正在监听中...`);
});
