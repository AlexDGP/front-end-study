const express = require("express");
const app = express();
app.get("/server", (request, response) => {
  response.setHeader("Access-Control-Allow-Origin", "*"); // 允许跨域请求域名
  response.setHeader("Access-Control-Allow-Method", "*"); // 允许跨域请求方法
  response.setHeader("Access-Control-Allow-Headers", "*"); // 允许跨域头信息

  response.send("Hello CORS"); // 设置响应体
});

// 监听8000端口启动服务
const port = 8000;
app.listen(port, () => {
  console.log(`服务已启动,${port}端口正在监听中...`);
});
