const express = require("express");

const app = express();

app.all("/json-server", (request, response) => {
  response.setHeader("Access-Control-Allow-Origin", "*"); // 允许跨域

  const data = { name: "Alex" };
  let str = JSON.stringify(data);
  response.send(str);
});

const port = 8000;
app.listen(port, () => {
  console.log(`服务已启动,${port}端口正在监听中...`);
});
