const express = require("express");

const app = express();

app.all("/json-server", (request, response) => {
  response.setHeader("Access-Control-Allow-Origin", "*"); // 允许跨域

  const data = { name: "Alex" };
  let str = JSON.stringify(data);
  setTimeout(() => {
    response.send(str);
  }, 3000); // 设置3秒后返回结果
});

const port = 8000;
app.listen(port, () => {
  console.log(`服务已启动,${port}端口正在监听中...`);
});
