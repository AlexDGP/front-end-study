const { ipcRenderer, contextBridge } = require("electron");
const fs = require("fs");

// const content = fs.readFileSync("package.json", "utf-8");
// console.log(content);

window.addEventListener("DOMContentLoaded", () => {
  console.log(document.querySelector("h1"));
});

window.hd = "后盾人";
console.log("preload", window);
console.log("preload", window.hd);

contextBridge.exposeInMainWorld("api", {
  saveFile() {
    ipcRenderer.send("saveFile");
  },
  add(callback) {
    ipcRenderer.on("add", (event, args) => {
      callback(args);
    });
  },
  message(event, msg) {
    ipcRenderer.send("message");
  },
  async uploadFile(callback) {
    const file = await ipcRenderer.invoke("uploadFile");
    callback(file);
    // document.getElementById("counter").innerText = file;
  },

  setTitle(title) {
    ipcRenderer.send("setTitle", title);
  },
});

window.addEventListener("DOMContentLoaded", () => {
  for (const app of ["node", "chrome", "electron"]) {
    document.getElementById(app).innerText = `${app}:${process.versions[app]}`;
  }
  document.getElementById("addBtn").addEventListener("click", () => {
    document.getElementById("counter").innerText =
      Number(document.getElementById("counter").innerText) + 1;
  });
});

ipcRenderer.on("message", (event, msg) => {
  console.log(msg);
});
