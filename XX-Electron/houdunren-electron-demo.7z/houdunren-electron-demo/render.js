console.log("render", window);
console.log("render", window.hd);
// api.hd();
document.getElementById("saveFileBtn").addEventListener("click", () => {
  window.api.saveFile();
});

window.api.add((value) => {
  document.getElementById("counter").innerText =
    Number(document.getElementById("counter").innerText) + value;
});

document.getElementById("messageBtn").addEventListener("click", () => {
  window.api.message();
});

document.getElementById("uploadFileBtn").addEventListener("click", () => {
  window.api.uploadFile((file) => {
    document.getElementById("counter").innerText = file;
  });
});

document.getElementById("setTitle").addEventListener("click", () => {
  const title = document.querySelector("input").value;
  window.api.setTitle(title);
});
