const { app, BrowserWindow, ipcMain, Menu, dialog } = require("electron");
const path = require("path");

function createWindow() {
  const mainWin = new BrowserWindow({
    width: 600,
    height: 600,
    x: 3200, // 初始窗口位置x
    y: 100, // 初始窗口位置y
    alwaysOnTop: true, // 窗口置顶
    // frame: false, // 删除内置边框
    // transparent: true, // 透明背景(frame: false才生效)
    webPreferences: {
      preload: path.resolve(__dirname, "preload.js"),
      nodeIntegration: true, // preload.js开启node能力
    },
  });

  mainWin.loadFile(path.resolve(__dirname, "index.html"));
  mainWin.webContents.openDevTools();

  const menu = [
    {
      label: "菜单",
      submenu: [
        {
          label: "add",
          click: () => {
            mainWin.webContents.send("add", 100);
          },
        },
      ],
    },
  ];

  Menu.setApplicationMenu(Menu.buildFromTemplate(menu));
}

app.whenReady().then(() => {
  createWindow();
});

//region ios适配
app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});

app.on("activate", () => {
  createWindow();
});
//endregion

ipcMain.on("saveFile", () => {
  console.log("saveFile");
});

ipcMain.on("message", (event) => {
  BrowserWindow.fromWebContents(event.sender).send("message", "已经收到通知");
});

ipcMain.handle("uploadFile", async (event) => {
  const { filePaths } = await dialog.showOpenDialog({});
  return filePaths[0];
});

ipcMain.on("setTitle", (event, value) => {
  console.log(value);
  BrowserWindow.fromWebContents(event.sender).title = value;
});
